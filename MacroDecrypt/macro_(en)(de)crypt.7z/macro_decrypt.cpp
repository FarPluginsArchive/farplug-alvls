#include <stdio.h>
#include <string.h>
#include <malloc.h>

void my_print(int indent, const char *ptr, int length)
{
  for (int i=0; i<indent*2; i++)
    printf(" ");
  for (int i=0; i<length; i++, ptr++)
    printf("%c",*ptr);
}

int main(int argc, char **argv)
{
  FILE *f = fopen(argv[1],"r");
  fseek(f,0,SEEK_END);
  int size = ftell(f);
  fseek(f,0,SEEK_SET);

  char *buf = (char *) malloc(size+1);

  size = fread(buf,1,size,f);
  fclose(f);

  buf[size] = 0;

  char *ptr = buf;
  int indent = 0;
  int normal_out = 0;
  int line = 0;
  int inquotes = 0;
  int space = 0;
  int space_line = line;

  while (*ptr)
  {
    if (*ptr == '$')
    {
      char *saveptr = ptr;
      ptr++;
      if (!strnicmp(ptr,"if",2) || !strnicmp(ptr,"rep",3) || !strnicmp(ptr,"while",5))
      {
        while (*ptr && *ptr != '(') ptr++;
        if (*ptr)
        {
          ptr++;
          int bracket=1;
          while (bracket && *ptr)
          {
            if (*ptr == '(')
              bracket++;
            if (*ptr == ')')
              bracket--;
            ptr++;
          }
        }
        if (line)
          printf("\n");
        line++;
        my_print(indent,saveptr,ptr-saveptr);
        indent++;
        while (*ptr == ' ')
          ptr++;
        normal_out = 0;
        continue;
      }
      else if (!strnicmp(ptr,"else",4))
      {
        indent--;
        ptr += 4;
        if (line)
          printf("\n");
        line++;
        my_print(indent,saveptr,ptr-saveptr);
        indent++;
        while (*ptr == ' ')
          ptr++;
        normal_out = 0;
        continue;
      }
      else if (!strnicmp(ptr,"end",3))
      {
        indent--;
        ptr += 3;
        if (line)
          printf("\n");
        line++;
        my_print(indent,saveptr,ptr-saveptr);
        while (*ptr == ' ')
          ptr++;
        normal_out = 0;
        continue;
      }
      ptr = saveptr;
    }

    if (!normal_out)
    {
      if (line)
        printf("\n");
      line++;
      my_print(indent,"",0);
      normal_out = 1;
    }
    if (*ptr == '"')
    {
      if (inquotes && *(ptr-1) != '\\' && (ptr - buf > 2) && *(ptr-2) != '\\' && *(ptr-3) != '\\')
        inquotes = 0;
      else
        inquotes = 1;
    }
    if (*ptr == ' ' && !inquotes)
    {
      if (!space)
        space_line = line;
      space = 1;
    }
    else
    {
      if (space && space_line == line)
        printf(" ");
      space = 0;
      printf("%c",*ptr);
    }
    ptr++;
  }

  free(buf);
  printf("\n");
  return 0;
}
