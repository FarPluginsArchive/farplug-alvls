#include <stdio.h>
#include <string.h>
#include <malloc.h>

int main(int argc, char **argv)
{
  FILE *f = fopen(argv[1],"r");
  fseek(f,0,SEEK_END);
  int size = ftell(f);
  fseek(f,0,SEEK_SET);

  char *buf = (char *) malloc(size+1);

  size = fread(buf,1,size,f);
  fclose(f);

  buf[size] = 0;

  char *ptr = buf;
  int line = 0;

  while (*ptr)
  {
    while (*ptr == ' ')
      ptr++;

    if (*ptr && *ptr != '#' && *ptr != '\n' && *ptr != '\r')
    {
      char *saveptr = ptr;
      while (*ptr && *ptr != '\n' && *ptr != '\r')
        ptr++;
      if (line)
        printf(" ");
      line++;
      for (int i=0; i<ptr-saveptr; i++)
        printf("%c",saveptr[i]);
    }
    else
    {
      while (*ptr && *ptr != '\n' && *ptr != '\r')
        ptr++;
    }

    while (*ptr == '\n' || *ptr == '\r')
      ptr++;
  }

  free(buf);
  return 0;
}
